<head>
        <meta charset="utf-8" />
        <link rel="stylesheet" href="GBAFpresentation.css" />
        <title>GBAF</title>
    </head>

<footer>
		<h1 ><a href="sommaire.php">Mentions légales</a> | <a href="sommaire.php">Contact</a> </h1>
</footer>