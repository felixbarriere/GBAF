<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8" />
        <link rel="stylesheet" href="GBAFpresentation.css" />
        <title>GBAF</title>
    </head>
    <body>
			<div id="bloc_page_utilisateur">
							
				<div id="header_connexion">
					<img class="logo_connexion" src="images/logo.png" alt="Logo GBAF" />
				<h2>Le Groupement Banquaire Assurance Francais </h2>						
				</div>    

				<h1 id="titre_centre">Inscription</h1>													
				<section>
												
				<form action="inscription.php" method="post">
			
					<p>
						<label for="nom"> Nom:</label>   <input type="text" name="nom" id="nom"/><br />
						
						<label for="prenom"> Prenom: </label>  <input type="text" name="prenom" id="prénom"/></label><br />	
						
						<label for="username"> UserName: </label>   <input type="text" name="username" id="username"/></label><br />	

						<label for="password"> Password: </label>   <input type="password" name="password" id="password"/><br />
						
						<label for="question_secrète"> Question secrète: </label>   <input type="text" name="question_secrete" id="question_secrete"/></label><br />	
						
						<label for="réponse_question_secrète"> réponse à votre question secrète: </label>   <input type="text" name="reponse_question_secrete" id="reponse_question_secrete"/></label><br />
						
						<input type="submit" name="envoyer" />
					</p>
				</form>	

	<?php
		if (isset($_POST["envoyer"]))			
		{				
			if (empty($_POST['nom']) OR empty($_POST['prenom']) OR empty($_POST['username']) OR empty($_POST['password']) OR empty($_POST['question_secrete']) OR empty($_POST['reponse_question_secrete']))
			{
				echo '<p class="error_message"> Veuillez remplir tous les champs </p>';
			}					
			else{
				// Connexion à la base de données
				try
				{
					$bdd = new PDO('mysql:host=localhost;dbname=gbaf;charset=utf8', 'root','');
				}
				catch(Exception $e)
				{
						die('Erreur : '.$e->getMessage());
				}

				$username = htmlspecialchars($_POST['username']);
				$verify_username = $bdd->prepare('SELECT username FROM informations WHERE username=?');
				$verify_username->execute(array($username));
				$user = $verify_username->rowCount();	
				if ($user >=1)
				{
					echo '<p class="error_message"> pseudo existant </p>';
				}
					else{				
					// Hachage du mot de passe
					
					$pass_hache = password_hash(htmlspecialchars($_POST['password']), PASSWORD_DEFAULT);
													
					// Insertion du message à l'aide d'une requête préparée
									
					try
					{
						$req = $bdd->prepare('INSERT INTO informations (nom, prenom, username, password,question_secrete, reponse_question_secrete) VALUES( :nom, :prenom, :username, :password, :question_secrete, :reponse_question_secrete)');					
						
						$req->execute(array(
					':nom' => $_POST['nom'],
					':prenom' => $_POST['prenom'],
					':username' => $_POST['username'],
					':password' => $pass_hache,
					':question_secrete' => $_POST['question_secrete'],
					':reponse_question_secrete' => $_POST['reponse_question_secrete']));	
					}
					catch(Exception $e)
					{
							die('Erreur : '.$e->getMessage());
					}
					
					header ('Location: connexion.php');
				}	
			}
		}	
				

			?>
				</section>
				
			</div>		
    </body>
	<?php include("footer.php");?>
</html>
