<?php include("menu1.php");?>
<?php									
	$bdd = new PDO('mysql:host=localhost;dbname=gbaf;charset=utf8', 'root', '');
	
	if(isset($_GET['t'], $_GET['id']) AND !empty ($_GET['t']) AND !empty($_GET['id']))
		{
			$getid = (int) $_GET['id'];
			$gett = (int) $_GET['t'];
			$id_membre = $_SESSION['id'];
			
			
			$check = $bdd->prepare('SELECT ID FROM partenaires WHERE ID=?');
			$check->execute(array($getid));
			
			var_dump($getid);
			var_dump($id_membre);
			var_dump($gett);
			
			if($check->rowCount() == 1){
				if($gett == 1) {
					$check_like = $bdd->prepare('SELECT id FROM likes WHERE id_article = ? AND id_membre = ?');
					$check_like->execute(array($getid, $id_membre));
					
					$delete = $bdd->prepare('DELETE FROM dislikes WHERE id_article = ? AND id_membre = ?');
					$delete->execute(array($getid, $id_membre));
					
					if($check_like->rowCount() == 1) {
					$delete = $bdd->prepare('DELETE FROM likes WHERE id_article = ? AND id_membre = ?');
					$delete->execute(array($getid, $id_membre));
					} else {					
					$ins = $bdd->prepare('INSERT INTO likes (id_article, id_membre) VALUES (?, ?)');
					$ins->execute(array($getid, $id_membre));
					}	
					
				} elseif ($gett == 2) {
					$check_dislike = $bdd->prepare('SELECT id FROM dislikes WHERE id_article = ? AND id_membre = ?');
					$check_dislike->execute(array($getid, $id_membre));
					
					$delete = $bdd->prepare('DELETE FROM likes WHERE id_article = ? AND id_membre = ?');
					$delete->execute(array($getid, $id_membre));
					
					if($check_dislike->rowCount() == 1) {
					$delete = $bdd->prepare('DELETE FROM dislikes WHERE id_article = ? AND id_membre = ?');
					$delete->execute(array($getid, $id_membre));
					} else {
						$ins = $bdd->prepare('INSERT INTO dislikes (id_article, id_membre) VALUES (?, ?)');
						$ins->execute(array($getid, $id_membre));
					}
				}
					
					
				
				header('Location: ' . $_SERVER['HTTP_REFERER']);
				
			} else{
				echo('erreur');
			}
		} else {
			echo ('erreur!');
		}	
?>