<header>
	<div id="titre_principal">
		<div id="logo">
			<img src="images/logo.png" alt="Logo GBAF" />
				<h1>GBAF</h1>    
		</div>                  
	</div>
					
	<nav>
		<ul>
			<li> 	
				 <a href="inscription.php" > Pas encore inscrit? </a>
			</li>														
		</ul>
						
		
	</nav>
</header>

