<?php include("menu1.php");?>
<?php
	// Connexion à la base de données

	try
	{
		$bdd = new PDO('mysql:host=localhost;dbname=gbaf;charset=utf8', 'root','');
	}
	catch(Exception $e)
	{
			die('Erreur : '.$e->getMessage());
	}
	
	// Hachage du mot de passe
		$pass_hache = password_hash(htmlspecialchars($_POST['password']), PASSWORD_DEFAULT);		
		$actualusername = $_SESSION['username'];
		
		$nom = htmlspecialchars($_POST['nom']);
		$prenom = htmlspecialchars($_POST['prenom']);
		$username = htmlspecialchars($_POST['username']);
		$question_secrete = htmlspecialchars($_POST['question_secrete']);
		$reponse_question_secrete = htmlspecialchars($_POST['reponse_question_secrete']);	
	
		//tous les champs doivent etre remplis
		if (!empty($nom) && !empty($prenom) && !empty($username) && !empty($pass_hache) && !empty($question_secrete) && !empty($reponse_question_secrete)) 
			{			
			$req = $bdd->prepare('UPDATE informations SET nom = ?, prenom= ?, username= ?, password= ?,question_secrete= ?, reponse_question_secrete = ? WHERE username = ?');					
		
			$req->execute(array($nom, $prenom, $username, $pass_hache, $question_secrete, $reponse_question_secrete, $actualusername  ));	
	
			header('Location: connexion.php');
			echo 'Vos informations ont bien été modifiées !';
	
			} else 	{
				echo 'Veuillez remplir tous les champs !';
				header('Location: profil.php');
					}	
	//header('Location: GBAFpresentation.php');
	//WHERE actualusername=:actualusername
?>
