<?php 
	if (isset ($_POST['username']) AND isset ($_POST['nouveau_mot_de_passe']))
	{
		// Connexion à la base de données
	
		try
		{
			$bdd = new PDO('mysql:host=localhost;dbname=gbaf;charset=utf8', 'root','');
		}
		catch(Exception $e)
		{
				die('Erreur : '.$e->getMessage());
		}

		// Hachage du mot de passe
			$pass_hache = password_hash($_POST['nouveau_mot_de_passe'], PASSWORD_DEFAULT);		
			
			$username = $_POST['username'];
			
		try
		{
			$req = $bdd->prepare('UPDATE informations SET password = ? WHERE username = ?');					
			
			$req->execute(array($pass_hache, $username));
			
		}
		catch(Exception $e)
		{
				die('Erreur : '.$e->getMessage());
		}
				
		
		header('Location: connexion.php');
		echo 'Vos informations ont bien été modifiées !';
		
				
		var_dump($req);	
	
	if("username" != $username)
		{
			echo 'Informations incorrectes !';
		}	
	}	
	
	if (empty($_POST['username']) OR empty($_POST['nouveau_mot_de_passe']))
	{
		header('Location: question_secrete.php');
	}	
	

//$2y$10$78MZc.2AQf/rUdDkVa7AAejBUK/T8AnNFUOOyj34yhGI0cWFFoNaK	
//$2y$10$qWXTHdqCE/xP/kk7X0bzAejosLM7M613fQtus4AiqS3DFL5b39tu2
//$2y$10$25sPHwiKJkgiVWI91457RuFUxkVnEFJhY3ZXUP0sIpNQPpUjNp73O
//$2y$10$9TqbHK/Ai6OqF4tExdFJe.CuCjO.LavNtoOSpv/2IAtZj4ieJRrgG
?>


