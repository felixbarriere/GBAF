

<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8" />
        <link rel="stylesheet" href="GBAFpresentation.css" />
        <title>GBAF</title>
    </head>
    <body>
			<div id="bloc_page_utilisateur">
				<?php include("menu1.php");?>


	<section>
		<article>
			<h1> Présentation des acteurs </h1>
				
				
				<div>
				<?php 
				try
					{
					$bdd = new PDO('mysql:host=localhost;dbname=gbaf;charset=utf8', 'root', '');
					}
					catch (Exception $e)
					{							
					die('Erreur : ' . $e->getMessage());
					}														
					//affichage de la description du partenaire
					
					$id_partenaire = $_GET['id_billet'];
					$reponse = $bdd->prepare('SELECT * FROM partenaires WHERE id = :id');
					$reponse->execute(array(
							'id' => $id_partenaire)); 
					$donnees = $reponse->fetch();
					
					?> <h1><?php echo $donnees['nom'] ?></h1> <?php

					
						echo '<div id="partenaire3"><img id="logo_partenaire2" src = "'. ($donnees['logo']). '"/> <br><br>';
					
						echo  $donnees['description'] . ' </div>';																
					$reponse->closeCursor();		
					
															
					//affichage des boutons likes/dislikes
					$id = $donnees['ID'];
					
					$likes = $bdd->prepare('SELECT id FROM likes WHERE id_article = ?');
					$likes->execute(array($id));
					$likes = $likes->rowCount();
					
					$dislikes = $bdd->prepare('SELECT id FROM dislikes WHERE id_article = ?');
					$dislikes->execute(array($id));
					$dislikes = $dislikes->rowCount();
				?>
				
				<br> <br>
				<a href="like.php?t=1&id=<?= $id ?>&id=<?=$id_partenaire?>"> J'aime </a> (<?= $likes ?>) 
				<br>				
				<a href="like.php?t=2&id=<?= $id ?>"> Je n'aime pas </a> (<?= $dislikes ?>) <br>
																
				</div>
				
			<br/>	
				 
				 <h2>Faites-nous part de vos retour!</h2>
				 	
				<form action="presentation.php?id_billet=<?php echo $donnees['ID']; ?>" method="post">								
									
				<label for="message"> Message: </label>   <input type="text" name="message" id="message"/></label><br />							
				<input type="submit" value="envoyer" name="envoyer" />
								
				</form>	
				
				<?php
				//envoie et ecriture des commentaires (sur connexion.php)
				
					if (isset ($_POST["envoyer"]))
					{
						if (empty ($_POST['message']))
						{
							echo '<p class="error_message"> Merci de remplir le champ</p>';
						}
						else
						{
					
					// Insertion du message à l'aide d'une requête préparée

					$req = $bdd->prepare('INSERT INTO commentaires (ID_user, message, id_article) VALUES(?,?,?)');
					$req->execute(array($_SESSION['username'], htmlspecialchars($_POST['message']), $donnees['ID']));							
								
						echo 'Votre message a bien été ajouté !';
						}			
					}
				?>
								
															
			<div>
				<h2>Commentaires</h2>
								
				<?php
				//affichage des commentaires										
									
				// On récupère tout le contenu de la table
				$reponse = $bdd->prepare('SELECT ID_user, message, date_message FROM commentaires WHERE id_article = ?  ORDER BY ID DESC LIMIT 0, 15');
				$reponse->execute([$id]);
				
				// On affiche chaque entrée une à une
				while ($donnees = $reponse->fetch())
				{
				echo '<p><strong>' . $donnees['ID_user'] . ' </strong>le ' .$donnees['date_message'] . ' <br/>' . $donnees['message'] . '</p>';
				}							
									
				$reponse->closeCursor();
				?>
																
			</div>
		</article>
		<br>
			<p> Retourner sur la <a href="sommaire.php"> présentation de nos partenaires </a>.</p>
		</section>
				
			</div>		
    </body>
	<?php include("footer.php");?>
</html>
