<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8" />
        <link rel="stylesheet" href="GBAFpresentation.css" />
        <title>GBAF</title>
    </head>
    <body>
			<div id="bloc_page_utilisateur">
				<?php include("menu1.php");?>
				<?php
					// Connexion à la base de données
					try
					{
						$bdd = new PDO('mysql:host=localhost;dbname=gbaf;charset=utf8', 'root','');
					}
					catch(Exception $e)
					{
							die('Erreur : '.$e->getMessage());
					}				

					$username=$_SESSION['username'];


					// Affichage des informations à l'aide d'une requête préparée
				
					$req = $bdd->prepare('SELECT nom, prenom, username, question_secrete, reponse_question_secrete FROM informations WHERE username = :username');
					$req->execute(array(
					'username' => $username));
					$resultat = $req->fetch();	
																
				?>


	<h1>Paramètres du compte</h1>
						
	<p id="titre_centre"> Modifier vos informations  </p>
	
		<section>			
																				
			<p>
				<form action="modification_data.php" method="POST"> 
				<label for="nom"> Nom:</label>   <input type="text" name="nom" id="nom" value= '<?php echo $resultat['nom']?>'/><br />
							
				<label for="prenom"> Prenom: </label>  <input type="text" name="prenom" id="prénom"value= '<?php echo $resultat['prenom']?>'/></label><br />	
							
				<label for="username"> UserName: </label>   <input type="text" name="username" id="username"value= '<?php echo $resultat['username']?>'/></label><br />	

				<label for="password"> Password: </label>   <input type="password" name="password" id="password"/><br />
							
				<label for="question_secrète"> Question secrète: </label>   <input type="text" name="question_secrete" id="question_secrete"value= '<?php echo $resultat['question_secrete']?>'/></label><br />	
							
				<label for="réponse_question_secrète"> réponse à votre question secrète: </label>   <input type="text" name="reponse_question_secrete" id="reponse_question_secrete"/></label><br />
							
				<input  type="submit" value="valider les modifications" />
			</form>										
		</p>
											
		<br>
	<p> Retourner sur la <a href="sommaire.php"> présentation de nos partenaires </a>.</p>
					
	</section>
				
			</div>		
    </body>
	<?php include("footer.php");?>
</html>
