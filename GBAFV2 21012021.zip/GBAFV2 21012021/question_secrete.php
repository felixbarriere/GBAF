<!DOCTYPE html>

<html>
    <head>
        <meta charset="utf-8" />
        <link rel="stylesheet" href="GBAFpresentation.css" />
        <title>GBAF</title>
    </head>
	
	
    <body>
			<div id="bloc_page_utilisateur">
			
			<?php include("menu2.php");?>
							
			<div id="header_connexion">
				<img class="logo_connexion" src="images/logo.png" alt="Logo GBAF" />
					<h2>Le Groupement Banquaire Assurance Francais	</h2>						
			</div>                  																	
							
	<section>
	
	<p>Répondez à votre question secrète afin de récupérer votre mot de passe:</p>
														
		<form action="question_secrete2.php" method="POST">						
												
			<label for="username"> username: </label>   <input type="username" name="username" id="username"/><br>																																						
			<p> <input type="submit"  value="envoyer"/></p>
		</form>
					
		
		
	
			
				
			</div>		
    </body>
	<?php include("footer.php");?>
</html>
