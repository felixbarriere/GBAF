<?php
if (isset ($_POST['username']))
    {         
		  $username = htmlspecialchars($_POST['username']);
		  
      // connection a la table "informations"
          try
			  {
				   $bdd = new PDO(
				   'mysql:host=localhost;dbname=gbaf','root','');
			  }
     
          catch(Exception $e)
			  {
				die('Erreur : '.$e->getMessage());
			  }
			  
		// On récupère tout le contenu de la table "informations"
		$req = $bdd->prepare('SELECT * FROM informations WHERE username = :username');
		$req->execute(array(
			'username' => $username));
		$resultat = $req->fetch();		



		if (!$resultat)
		{
			header('Location: question_secrete.php');
			echo 'Mauvais identifiant';
			
		}
		
	}
if (empty($username))
	{
		header('Location: question_secrete.php');
	}
?>

<!DOCTYPE html>

<html>
    <head>
        <meta charset="utf-8" />
        <link rel="stylesheet" href="GBAFpresentation.css" />
        <title>GBAF</title>
    </head>
	
	
    <body>
			<div id="bloc_page_utilisateur">
			
			<?php include("menu2.php");?>
							
						<div id="header_connexion">
							<img class="logo_connexion" src="images/logo.png" alt="Logo GBAF" />
								<h2>Le Groupement Banquaire Assurance Francais	</h2>						
						</div>                  																	
						<p>Répondez à votre question secrète afin de récupérer votre mot de passe:</p>
										
				
				
				<p> Votre question: 
				
				<?php echo $resultat['question_secrete']; ?>			
								
				</p>
				
				<br>
				<section>
					<form action="question_secrete3.php" method="POST">
																					
						<label for="username"> username: </label>   <input type="username" name="username" id="username"/><br>																
						<label for="reponse_question_secrete"> Réponse: </label>   <input type="reponse_question_secrete" name="reponse_question_secrete" id="reponse_question_secrete"/>
						<br />											
						<p> <input type="submit"  value="envoyer"/></p>
					</form>
					

										
				</section>
				
			
				
			</div>		
    </body>
	<?php include("footer.php");?>
</html>