<?php
if (isset ($_POST['username']) AND isset ($_POST['reponse_question_secrete']))
		{         
		 
		  $username = htmlspecialchars($_POST['username']);
		  $reponse_question_secrete = htmlspecialchars($_POST['reponse_question_secrete']);
		  	  		
		// connection a la table "informations"
          try
			  {
				   $bdd = new PDO(
				   'mysql:host=localhost;dbname=gbaf','root','');
			  }
     
          catch(Exception $e)
			  {
				die('Erreur : '.$e->getMessage());
			  }
			  
		// On récupère tout le contenu de la table "informations"
		$req = $bdd->prepare('SELECT username, reponse_question_secrete FROM informations WHERE username = :username');
		$req->execute(array('username' => $username));
		$resultat = $req->fetch();		
		
		$isdataCorrect = $reponse_question_secrete == $resultat['reponse_question_secrete'];
		
		if ($isdataCorrect)
		{
			
		}
		else
			{
				header ('Location:question_secrete.php');
			}					
		
		}
if (empty($username) OR empty($reponse_question_secrete))
	{
		header('Location: question_secrete.php');
	}
	
?>

<!DOCTYPE html>

<html>
    <head>
        <meta charset="utf-8" />
        <link rel="stylesheet" href="GBAFpresentation.css" />
        <title>GBAF</title>
    </head>
	
	
    <body>
			<div id="bloc_page_utilisateur">
			
			<?php include("menu2.php");?>
							
						<div id="header_connexion">
							<img class="logo_connexion" src="images/logo.png" alt="Logo GBAF" />
								<h2>Le Groupement Banquaire Assurance Francais	</h2>						
						</div>                  																	
						<p>Réponse correcte! <br>
						Vous pouvez désormais réenregistrer votre mot de passe</p>																					
				<br>
				<section>
				
						<form method="POST" action="nouveau_mot_de_passe_data.php" >
						
							<label for="username"> Username:  </label>  <input type="username" name="username" id="username"/>
							<br />
						
							<label for="nouveau_mot_de_passe"> Nouveau mot de passe:  </label>  <input type="password" name="nouveau_mot_de_passe" id="nouveau_mot_de_passe"/>
							<br>																																																																		
							<input type="submit"  value="envoyer" name="update"/></p>
					</form>
					

										
				</section>
				
			
				
			</div>		
    </body>
	<?php include("footer.php");?>
</html>