

<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8" />
        <link rel="stylesheet" href="GBAFpresentation.css" />
        <title>GBAF</title>
    </head>
    <body>
			<div id="bloc_page_utilisateur">
				
				<?php include("menu1.php");?>

				<section>
					<article>
						<h1>présentation du groupe</h1>
						
						<p>Le Groupement Banque Assurance Français (GBAF) est une fédération représentant les 6 grands groupes français :

							<li><a>BNP Paribas</a></li>
							<li><a>BPCE</a></li>
							<li><a>Crédit Agricole</a></li>
							<li><a>Crédit Mutuel-CIC</a></li>
							<li><a>Société Générale</a></li>
							<li><a>La Banque Postale</a></li></br>
							
	Même s’il existe une forte concurrence entre ces entités, elles vont toutes travailler
	de la même façon pour gérer près de 80 millions de comptes sur le territoire
	national.
	Le GBAF est le représentant de la profession bancaire et des assureurs sur tous
	les axes de la réglementation financière française. Sa mission est de promouvoir
	l'activité bancaire à l’échelle nationale. C’est aussi un interlocuteur privilégié des
	pouvoirs publics.</p>
						
							
			<img class="defense" src="images/defense.jfif" alt="defense" />						
								
				<h1> Présentation des acteurs </h1>
					<div id="partenaires">																										
									
				<?php									
					//aperçu des différents partenaires
					try
						{
							$bdd = new PDO('mysql:host=localhost;dbname=gbaf;charset=utf8', 'root', '');
						}
					catch (Exception $e)
						{							
							die('Erreur : ' . $e->getMessage());
						}
															
					$reponse = $bdd->query('SELECT nom, description, logo, ID FROM partenaires ORDER BY ID ASC LIMIT 0, 4 ');

				
				
					while ($donnees = $reponse->fetch())
					{
						$description = $donnees['description'];
						
						echo '<div id="partenaire3"> <br><img id="logo_partenaire" src = "'. ($donnees['logo']). '"/><h3>' . ($donnees['nom']) . '</h3> <p id="partenaire2">' . substr($description, 0, 106) .'...</p>';
						
						?><em><div id="afficher"><a id="afficher" href="presentation.php?id_billet=<?php echo $donnees['ID']; ?>">afficher plus</a></div></em><br>  </div>  <?php
					
						/*$lignes = explode("\n", $texte);
						$lignesAAfficher = array_slice($lignes, 0, 3);
						$texteAAfficher = implode("\n", $lignesAAfficher);*/

						
						
						
						
						
						/*$fichier=$donnees['description'];
						$tabfich=file($fichier);
						$nbr = 2;
						 
						for( $i = 0 ; $i <=count($tabfich) && $i < $nbr  ; $i++ )
						{
						echo $tabfich[$i]."</br>";
						}*/
					
					}											
					$reponse->closeCursor();
				?>								 								 									
			
					</div>
						
					</article>
				</section>
				
			</div>		
    </body>
	<?php include("footer.php");?>
</html>
