<footer>
		<h1 ><a href="sommaire.php">Mentions légales</a> | <a href="sommaire.php">Contact</a> </h1>
</footer>